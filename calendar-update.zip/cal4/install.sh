#!/bin/bash
# Ejecutar desde: ~/Documentos/Graficos GP/agility-dashboard/
BACKEND="backend/app"
cp cal4/app/api/v1/endpoints/calendar_events.py $BACKEND/api/v1/endpoints/calendar_events.py
cp cal4/app/api/v1/__init__.py $BACKEND/api/v1/__init__.py
cp cal4/app/services/confluence_service.py $BACKEND/services/confluence_service.py
echo "Listo — reiniciá el backend con: uvicorn app.main:app --reload"
